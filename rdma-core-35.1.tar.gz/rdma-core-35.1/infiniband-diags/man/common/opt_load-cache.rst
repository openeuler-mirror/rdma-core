.. Define the common option load-cache

**--load-cache <filename>**
Load and use the cached ibnetdiscover data stored in the specified
filename.  May be useful for outputting and learning about other
fabrics or a previous state of a fabric.


