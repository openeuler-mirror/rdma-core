.. Define the common option -K

**-K, --show_keys**
  show security keys (mkey, smkey, etc.) associated with the request.
