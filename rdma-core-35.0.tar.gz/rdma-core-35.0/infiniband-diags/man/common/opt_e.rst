.. Define the common option -e

-e      show send and receive errors (timeouts and others)
