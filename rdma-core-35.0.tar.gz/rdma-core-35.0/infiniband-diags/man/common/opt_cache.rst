.. Define the common option cache

**--cache <filename>**
Cache the ibnetdiscover network data in the specified filename.  This
cache may be used by other tools for later analysis.


